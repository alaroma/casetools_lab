#ifndef FILTER_H
#define FILTER_H

typedef struct _filter
{
	int32_t height;
	int32_t width;
} filter;

#endif